test_checkDrugSynonym <- function() {

  obs <- tryCatch(checkDrugSynonym(drugVector = NULL), error=conditionMessage)
  checkIdentical("input drugVector must be a string vector", obs)

  obs <- tryCatch(!file.exists(paste0(tempdir(),"/dhdrugs.RData")), error=conditionMessage)
  checkIdentical("data download is needed", obs)

}
