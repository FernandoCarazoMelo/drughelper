#' @title Download data from Chembl
#' @description If it has not been downloaded yet, downloads data of drugs
#' @param dir Name of the directory where data is downloaded
#' @return A dataset of drugs downloaded in current temp directory.
#' @importFrom utils download.file
#' @export

downloadAbsentFile <- function (dir = tempdir()){

  if(!file.exists(paste0(tempdir(),"/dhdrugs.RData"))) {

    library(tidyverse)
    dhdrugs <- read_delim("https://raw.githubusercontent.com/jaaaviergarcia/drughelper/main/dhdrugs.tsv",
                          "\t", escape_double = FALSE, trim_ws = TRUE)
    singleDrugSynonymsChembl<-c()
    data("singleDrugSynonymsChembl", envir = environment())

    for (i in 1:nrow(dhdrugs)){
      dhdrugs$synonyms[i] <- toupper(dhdrugs$synonyms[i])
    }

    dhdrugs$synonymsChembl <- singleDrugSynonymsChembl$Drug_synonyms


    for (j in 1:nrow(dhdrugs)){
      if (is.na(dhdrugs$synonyms[j]))
        dhdrugs$synonyms[j] <- dhdrugs$synonymsChembl[j]
      else
        dhdrugs$synonyms[j] <- paste(dhdrugs$synonymsChembl[j], dhdrugs$synonyms[j], sep=";;;")
    }

    dhdrugs <- dhdrugs[,-7]

    for (k in 1:nrow(dhdrugs)){

      vaux <- strsplit(dhdrugs$synonyms[k], ";;;")[[1]]
      vaux <- unique(vaux)
      dhdrugs$synonyms[k] <- paste(vaux, collapse = ";;;")

    }

    source("./R/AuxFunctions.R")
    dhdrugs <- updateTable(dhdrugs)

    dhdrugs$DrugHelper <- paste0("DH0",1:nrow(dhdrugs))

    dhdrugs <- subset(dhdrugs, select = c(8,2,1,4,5,6,7,3))

    save(dhdrugs, file = paste0(tempdir(), "/dhdrugs.RData"))



  }
}


