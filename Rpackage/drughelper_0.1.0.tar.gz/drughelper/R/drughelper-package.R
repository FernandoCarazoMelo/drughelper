#' @name{drughelper}
#' @aliases{drughelper-package}
#' @title{drughelper}
#' @description{
#'   To learn more about drughelper, start with the vignettes:
#'     \code{browseVignettes(package = "drughelper")}
#' }
#'
#'
#'
#' @author{
#'   \strong{Maintainer}: Javier Garcia  \email{a905125@alumni.unav.es}
#'
#'   Authors:
#'     \itemize{
#'       \item Javier Garcia
#'       \item Fernando Carazo
#'     }
#'
#'   Other contributors:
#'     \itemize{
#'       \item Tecnun [copyright holder]
#'     }
#'
#' }
#'
#'
#'
#'
#' @keywords internal check
"_PACKAGE"


